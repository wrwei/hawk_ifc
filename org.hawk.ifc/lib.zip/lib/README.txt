This folder should be filled in with the following .jar files from
BIMserver 1.4.0. Some of them are in the bimserver-1.4.0-*.jar file,
and some of them are in the bimserver-lib-1.4.0-*.zip file:

antlr-2.7.7.jar
antlr-3.1.1.jar
antlr-3.1.1-runtime.jar
bimserver-1.4.0-FINAL-2015-08-25-buildingSMARTLibrary.jar
bimserver-1.4.0-FINAL-2015-08-25-ifc.jar
bimserver-1.4.0-FINAL-2015-08-25-ifcplugins.jar
bimserver-1.4.0-FINAL-2015-08-25-shared.jar
commons-codec-1.9.jar
commons-io-1.4.jar
gson-2.2.4.jar
guava-18.0.jar
jackson-annotations-2.5.0.jar
jackson-core-2.5.1.jar
jackson-databind-2.5.1.jar
javassist.jar
log4j-1.2.16.jar
slf4j-api-1.6.2.jar
slf4j-log4j12-1.6.2.jar
